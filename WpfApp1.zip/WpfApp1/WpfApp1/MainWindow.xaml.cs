﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            List<Kutyak> kutyakLista = new List<Kutyak>();

            StreamReader fajtakFile = new StreamReader("KutyaFajtak.csv");
            List<string> fajtak = new List<string>();
            fajtakFile.ReadLine();
            while (fajtakFile.EndOfStream != true)
            {
                fajtak.Add(fajtakFile.ReadLine());
            }

            StreamReader nevekFile = new StreamReader("KutyaNevek.csv");
            List<string> nevek = new List<string>();
            nevekFile.ReadLine();
            while (nevekFile.EndOfStream != true)
            {
                fajtak.Add(nevekFile.ReadLine());
            }

            StreamReader kutyakFile = new StreamReader("Kutyak.csv");
            kutyakFile.ReadLine();
            while (kutyakFile.EndOfStream != true)
            {
                string adatsor = kutyakFile.ReadLine();
                string nev = nevek.Where(x => x.Split(";")[0] == adatsor.Split(";")[2]).ToString();
                string fajta = fajtak.Where(x => x.Split(";")[0] == adatsor.Split(";")[1]).ToString();
                kutyakLista.Add(new Kutyak(nev, fajta, Convert.ToInt32(adatsor.Split(";")[3]), Convert.ToDateTime(adatsor.Split(";")[4])));
            }

            tbNevekSzama.Text = $"Beolvasott nevek: {kutyakLista.Count}db";
            tbAtlagEletkor.Text = $"Átlag életkor: {kutyakLista.Average(x => x.Eletkor):.00}év";
            Kutyak legidosebb = kutyakLista.Where(x => x.Eletkor == kutyakLista.Max(x => x.Eletkor));
            tbLegidosebbKutya.Text = $"{}";
        }
    }
}
