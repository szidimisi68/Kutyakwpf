﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class Kutyak
    {
        string nevek;
        string fajta;
        int eletkor;
        DateTime utolsoEllenorzes;

        

        public Kutyak(string nevek, string fajta, int eletkor, DateTime utolsoEllenorzes)
        {
            this.nevek = nevek;
            this.fajta = fajta;
            this.eletkor = eletkor;
            this.utolsoEllenorzes = utolsoEllenorzes;
        }

        public string Nevek { get => nevek; set => nevek = value; }
        public string Fajta { get => fajta; set => fajta = value; }
        public int Eletkor { get => eletkor; set => eletkor = value; }
        public DateTime UtolsoEllenorzes { get => utolsoEllenorzes; set => utolsoEllenorzes = value; }
    }
}
